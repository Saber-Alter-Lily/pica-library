package com.picalibrary.android;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

final class BridgeClient {
    static String get(Context c, String path) throws Exception {
        String host = BridgeStore.host(c);
        if (host.isEmpty()) throw new IllegalStateException("not paired");
        URL url = new URL(host.replaceAll("/$", "") + path);
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        con.setConnectTimeout(2500); con.setReadTimeout(3500);
        String token = BridgeStore.token(c);
        if (!token.isEmpty()) con.setRequestProperty("Authorization", "Bearer " + token);
        con.setRequestProperty("Accept", "application/json");
        int status = con.getResponseCode();
        BufferedReader r = new BufferedReader(new InputStreamReader(status >= 400 ? con.getErrorStream() : con.getInputStream()));
        StringBuilder b = new StringBuilder(); String line;
        while ((line = r.readLine()) != null) b.append(line);
        if (status >= 400) throw new IllegalStateException("HTTP " + status + ": " + b);
        return b.toString();
    }

    static List<String[]> library(Context c) throws Exception {
        JSONObject root = new JSONObject(get(c, "/mobile/v1/library?scope=favorites&limit=40"));
        JSONArray items = root.optJSONArray("items");
        if (items == null) items = root.optJSONArray("data");
        List<String[]> out = new ArrayList<>();
        if (items != null) for (int i = 0; i < items.length(); i++) {
            JSONObject o = items.optJSONObject(i); if (o == null) continue;
            out.add(new String[]{o.optString("comicId"), o.optString("title", "未命名漫画"), o.optString("author", "未知作者")});
        }
        return out;
    }
}
