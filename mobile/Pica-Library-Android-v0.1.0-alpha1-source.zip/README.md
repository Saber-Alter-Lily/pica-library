# Pica Library Android v0.1 Alpha 1

Clean-room Android client prototype for Pica Library.

## Current alpha scope
- Native Android shell: 漫画库 / 推荐 / 图鉴 / 我的
- Desktop pairing deep link: `picalibrary://pair?host=...&token=...`
- Bridge health/library client foundation
- Reader alpha: page controls, tap zones, toolbar toggle, volume-key page turn
- Demo content so the APK is usable before Desktop Mobile Bridge is implemented

## Clean-room boundary
MH-ARK is used only as behavior/configuration/navigation reference. No original source code, artwork, branding, icon or native library is copied into this project.

## Build
```bash
gradle :app:assembleDebug
```
Output: `app/build/outputs/apk/debug/app-debug.apk`
