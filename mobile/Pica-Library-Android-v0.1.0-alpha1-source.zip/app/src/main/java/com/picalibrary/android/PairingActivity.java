package com.picalibrary.android;

import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public class PairingActivity extends Activity {
    @Override public void onCreate(Bundle b){ super.onCreate(b); getWindow().setStatusBarColor(Ui.BG); render(); handleDeepLink(getIntent().getData()); }
    private void render(){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(Ui.dp(this,22),Ui.dp(this,24),Ui.dp(this,22),Ui.dp(this,24)); root.setBackgroundColor(Ui.BG);
        root.addView(Ui.text(this,"连接 Pica Library",28,Ui.TEXT,true)); Ui.gap(root,this,8); root.addView(Ui.text(this,"正式版将使用二维码一键配对。这个 alpha 已经支持 picalibrary://pair 深链，并保留隐藏的开发连接入口。",14,Ui.MUTED,false)); Ui.gap(root,this,18);
        Button scan=new Button(this); scan.setText("扫描电脑上的二维码（Alpha 占位）"); scan.setAllCaps(false); root.addView(scan);
        Ui.gap(root,this,18); TextView dev=Ui.text(this,"开发连接",14,Ui.MUTED,true); root.addView(dev);
        EditText host=new EditText(this); host.setHint("http://192.168.1.12:7788"); host.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_URI); root.addView(host);
        EditText token=new EditText(this); token.setHint("设备 Token（可空）"); root.addView(token);
        Button save=new Button(this); save.setText("保存连接"); save.setAllCaps(false); save.setOnClickListener(v->{String h=host.getText().toString().trim(); if(!h.isEmpty()){BridgeStore.save(this,h,token.getText().toString().trim(),"Pica Library Desktop"); finish();}}); root.addView(save);
        if(BridgeStore.paired(this)){Ui.gap(root,this,12); Button clear=new Button(this); clear.setText("解除配对"); clear.setAllCaps(false); clear.setOnClickListener(v->{BridgeStore.clear(this);finish();}); root.addView(clear);} setContentView(root);
    }
    private void handleDeepLink(Uri u){ if(u==null||!"picalibrary".equals(u.getScheme()))return; String host=u.getQueryParameter("host"); String token=u.getQueryParameter("token"); if(host!=null&&!host.isEmpty()){BridgeStore.save(this,host,token==null?"":token,"Pica Library Desktop"); finish();} }
}
