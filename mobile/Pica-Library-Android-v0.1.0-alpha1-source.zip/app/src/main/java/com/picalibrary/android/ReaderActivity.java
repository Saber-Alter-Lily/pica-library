package com.picalibrary.android;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

public class ReaderActivity extends Activity {
    private FrameLayout root; private TextView page; private LinearLayout controls; private int index=1; private final int total=24;
    @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(Color.BLACK); getWindow().setNavigationBarColor(Color.BLACK); render();}
    private void render(){
        root=new FrameLayout(this); root.setBackgroundColor(0xff121212);
        page=Ui.text(this,"",26,0xffeeeeee,true); page.setGravity(Gravity.CENTER); page.setBackground(Ui.rounded(0xff26232b,18,this)); FrameLayout.LayoutParams pp=new FrameLayout.LayoutParams(-1,-1); pp.setMargins(Ui.dp(this,18),Ui.dp(this,44),Ui.dp(this,18),Ui.dp(this,80)); root.addView(page,pp);
        controls=new LinearLayout(this); controls.setGravity(Gravity.CENTER); controls.setBackgroundColor(0xdd17151b);
        Button prev=button("上一页"); prev.setOnClickListener(v->flip(-1)); Button chapters=button("章节"); Button settings=button("设置"); Button next=button("下一页"); next.setOnClickListener(v->flip(1));
        controls.addView(prev,new LinearLayout.LayoutParams(0,Ui.dp(this,58),1)); controls.addView(chapters,new LinearLayout.LayoutParams(0,Ui.dp(this,58),1)); controls.addView(settings,new LinearLayout.LayoutParams(0,Ui.dp(this,58),1)); controls.addView(next,new LinearLayout.LayoutParams(0,Ui.dp(this,58),1)); FrameLayout.LayoutParams cp=new FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM); root.addView(controls,cp);
        root.setOnTouchListener((v,e)->{if(e.getAction()==MotionEvent.ACTION_UP){float x=e.getX(); if(e.getY()<root.getHeight()-Ui.dp(this,90)){ if(x<root.getWidth()*0.28f) flip(-1); else if(x>root.getWidth()*0.72f) flip(1); else toggleControls(); } } return true;});
        setContentView(root); update();
    }
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setAllCaps(false);b.setBackgroundColor(Color.TRANSPARENT);return b;}
    private void flip(int d){index=Math.max(1,Math.min(total,index+d));update();}
    private void update(){String title=getIntent().getStringExtra("title"); if(title==null)title="漫画"; page.setText(title+"\n\nPage "+index+" / "+total+"\n\nReader Core Alpha\n点击左右区域翻页 · 中间切换工具栏");}
    private void toggleControls(){controls.setVisibility(controls.getVisibility()==View.VISIBLE?View.GONE:View.VISIBLE);}
    @Override public boolean onKeyDown(int keyCode,KeyEvent event){if(keyCode==KeyEvent.KEYCODE_VOLUME_UP){flip(-1);return true;} if(keyCode==KeyEvent.KEYCODE_VOLUME_DOWN){flip(1);return true;} return super.onKeyDown(keyCode,event);}    
}
