package com.picalibrary.android;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends Activity {
    private LinearLayout content;
    private LinearLayout nav;
    private int current = 0;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Ui.BG);
        renderShell();
    }

    private void renderShell() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Ui.BG);
        ScrollView scroll = new ScrollView(this); content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(content, new ScrollView.LayoutParams(-1, -2));
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));
        nav = new LinearLayout(this); nav.setGravity(Gravity.CENTER); nav.setPadding(Ui.dp(this, 8), Ui.dp(this, 7), Ui.dp(this, 8), Ui.dp(this, 9));
        root.addView(nav, new LinearLayout.LayoutParams(-1, -2));
        setContentView(root);
        String[] labels = {"漫画库", "推荐", "图鉴", "我的"};
        for (int i=0;i<labels.length;i++) { final int idx=i; Button bt=new Button(this); bt.setText(labels[i]); bt.setAllCaps(false); bt.setTextSize(13); bt.setOnClickListener(v->{current=idx; showTab();}); nav.addView(bt,new LinearLayout.LayoutParams(0,Ui.dp(this,52),1)); }
        showTab();
    }

    private void showTab() {
        content.removeAllViews();
        if (current==0) library(); else if(current==1) recommendations(); else if(current==2) atlas(); else profile();
    }

    private void hero(String title, String subtitle) {
        Ui.gap(content,this,16);
        TextView t=Ui.text(this,title,30,Ui.TEXT,true); t.setPadding(Ui.dp(this,20),0,Ui.dp(this,20),0); content.addView(t);
        TextView s=Ui.text(this,subtitle,14,Ui.MUTED,false); s.setPadding(Ui.dp(this,20),Ui.dp(this,6),Ui.dp(this,20),Ui.dp(this,10)); content.addView(s);
    }

    private void library() {
        hero("漫画库","收藏、筛选并继续阅读你的漫画");
        LinearLayout chips=new LinearLayout(this); chips.setPadding(Ui.dp(this,16),0,Ui.dp(this,16),Ui.dp(this,8));
        for(String x:new String[]{"收藏","已下载","书架","最近阅读"}) { TextView p=Ui.pill(this,x,Ui.PRIMARY_SOFT,Ui.PRIMARY); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,-2); lp.setMargins(0,0,Ui.dp(this,8),0); chips.addView(p,lp); }
        content.addView(chips);
        if (BridgeStore.paired(this)) {
            LinearLayout c=Ui.card(this); c.addView(Ui.text(this,"已连接 " + BridgeStore.serverName(this),14,Ui.GOOD,true)); c.addView(Ui.text(this,"正在尝试读取 Desktop 漫画库…",13,Ui.MUTED,false)); content.addView(c);
            new Thread(() -> { try { List<String[]> items=BridgeClient.library(this); runOnUiThread(() -> { if(items.size()>0){ content.removeViews(3, Math.max(0, content.getChildCount()-3)); for(String[] it:items) comicCard(it[1],it[2],it[0]); } }); } catch(Exception ignored) {} }).start();
        }
        comicCard("夜航书库","Demo · 本地原型","demo-night");
        comicCard("偏好引力","Demo · 推荐链路占位","demo-gravity");
        comicCard("收藏宇宙","Demo · 图鉴联动占位","demo-atlas");
    }

    private void comicCard(String title,String author,String id){
        LinearLayout c=Ui.card(this); c.setClickable(true); c.addView(Ui.text(this,title,19,Ui.TEXT,true)); c.addView(Ui.text(this,author,13,Ui.MUTED,false)); Ui.gap(c,this,8); LinearLayout row=new LinearLayout(this); row.addView(Ui.pill(this,"继续阅读",Ui.PRIMARY,0xffffffff)); row.addView(Ui.pill(this,"收藏",0xffeeeeee,Ui.TEXT)); c.addView(row); c.setOnClickListener(v->{Intent i=new Intent(this,ReaderActivity.class); i.putExtra("title",title); i.putExtra("comicId",id); startActivity(i);}); content.addView(c);
    }

    private void recommendations(){
        hero("为你推荐","Recommendation V3 将由 Desktop 作为唯一算法权威");
        String[][] rec={{"高匹配主题","偏好集中于 长篇 / 剧情 / 奇幻","92%"},{"作者延伸","基于收藏作者与相邻标签召回","87%"},{"探索路线","保持熟悉度，同时加入少量新主题","74%"}};
        for(String[] r:rec){LinearLayout c=Ui.card(this); LinearLayout top=new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL); TextView t=Ui.text(this,r[0],18,Ui.TEXT,true); top.addView(t,new LinearLayout.LayoutParams(0,-2,1)); top.addView(Ui.pill(this,r[2],Ui.PRIMARY_SOFT,Ui.PRIMARY)); c.addView(top); c.addView(Ui.text(this,r[1],13,Ui.MUTED,false)); content.addView(c);}    }

    private void atlas(){
        hero("收藏图鉴","把你的收藏变成可阅读的兴趣地图");
        String[][] data={{"收藏总体画像","你的收藏正在形成稳定的长篇剧情偏好。"},{"主要兴趣主题","剧情推进 · 奇幻世界 · 角色关系 · 长篇连载"},{"兴趣宇宙","从核心主题向相邻作者与作品系列扩展。"},{"偏好版图","稳定核心 58% · 相邻探索 29% · 新主题 13%"}};
        for(String[] x:data){LinearLayout c=Ui.card(this); c.addView(Ui.text(this,x[0],18,Ui.TEXT,true)); Ui.gap(c,this,6); c.addView(Ui.text(this,x[1],14,Ui.MUTED,false)); content.addView(c);}    }

    private void profile(){
        hero("我的","连接、阅读设置和缓存");
        LinearLayout pair=Ui.card(this); pair.addView(Ui.text(this,BridgeStore.paired(this)?"Desktop 已连接":"连接 Pica Library Desktop",18,Ui.TEXT,true)); pair.addView(Ui.text(this,BridgeStore.paired(this)?BridgeStore.host(this):"扫码配对后，手机端无需保存 Pica 账号密码。",13,Ui.MUTED,false)); Button b=new Button(this); b.setAllCaps(false); b.setText(BridgeStore.paired(this)?"管理连接":"开始配对"); b.setOnClickListener(v->startActivity(new Intent(this,PairingActivity.class))); pair.addView(b); content.addView(pair);
        for(String[] x: Arrays.asList(new String[][]{{"阅读设置","滚动、双页、缩放、翻页区域、预加载"},{"缓存","有界页面缓存 · 可按漫画清理"},{"关于","Pica Library Android 0.1.0-alpha1 · Clean-room build"}})){LinearLayout c=Ui.card(this); c.addView(Ui.text(this,x[0],17,Ui.TEXT,true)); c.addView(Ui.text(this,x[1],13,Ui.MUTED,false)); content.addView(c);}    }
}
